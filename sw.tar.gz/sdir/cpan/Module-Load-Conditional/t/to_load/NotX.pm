use strict;
our $VERSION = 1;

package Y;

our $VERSION = 2;

package NotX;

our $VERSION = 3;

package X;

our $VERSION = 4;

1;
